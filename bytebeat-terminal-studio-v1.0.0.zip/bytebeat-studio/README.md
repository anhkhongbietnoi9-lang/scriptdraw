# BYTEBEAT TERMINAL STUDIO (BBTS) v1.0.0

A real, offline Bytebeat workstation for Termux/Android using only Python standard-library modules in the core. The UI is a hand-built ANSI TTY renderer. `curses` is intentionally not used because CPython documents it as unavailable on Android.

## Requirements
- Termux with Python 3.12+; development target Python 3.14+.
- Interactive ANSI terminal.
- No root, Node.js, browser, or Python third-party dependency is required for the core.

Install the baseline environment:

```sh
pkg update
pkg upgrade
pkg install python
python main.py
```

Optional audio fallbacks can be installed only when desired. `ffplay` may be supplied by a package that includes it, and `termux-media-player` is detected when its executable is available. On builds where Termux:API is separate, the package CLI and Android companion app are separate pieces. Availability depends on the Termux distribution/channel.

## Audio backend order
1. `termux-media-player`
2. `ffplay`
3. `mpv`
4. `aplay`
5. `NONE`

No backend is installed automatically. Playback becomes unavailable without one, but editing, parsing, visualization preview, project storage, presets and WAV export remain usable.

## Bytebeat syntax
Expression parsing is done by a custom lexer, precedence-aware parser, AST validator and compiler. Python `eval()` is never used. Only `t` is exposed in v1. Safe functions include `abs`, `min`, `max`, `int`, `floor`, `ceil`, `sqrt`, `sin`, `cos`, `pow`, and `clamp`.

Supported operators: `+ - * / % >> << & | ^ ~ > < >= <= == != ? : && ||`.

## Storage
```text
~/.bbts/
├── config.json
├── projects/
├── presets/
├── exports/
├── logs/
└── cache/
```
Projects use `.bbproj` JSON with schema version 1.

## Controls
`ENTER` play/resume, `SPACE` pause, `S` stop, `R` reset, `E` editor, `P` presets, `V` visualizer, `+/-` zoom, `W` export WAV, `O` settings, `?` help, `L` loop, `A` auto-preview, `Ctrl+S` save, `Ctrl+Z/Y` undo/redo, `Q` quit, `ESC` back/cancel.

## WAV export
Exports are streamed in chunks to an atomic temporary file, then verified with `wave`. V1 is PCM 8-bit mono only.

## Performance
`PERFORMANCE` targets 60 FPS and larger FFT sizes, `BALANCED` targets 30 FPS, and `BATTERY` targets 15 FPS with reduced visualizer work. Audio generation remains independent of UI frame rate.

## Troubleshooting
- **INTERACTIVE TERMINAL REQUIRED**: launch from a real Termux terminal, not redirected stdin.
- **AUDIO BACKEND UNAVAILABLE**: install or expose one of the supported executables, or continue offline and use WAV export.
- **TERMINAL TOO SMALL**: resize to at least 52×18 or use compact mode.
- **PROJECT FILE CORRUPTED**: restore from backup/autosave or load another `.bbproj`.

## Development
The source is split into parser, audio, project, visualizer, TUI and application layers. Do not run the app from a directory other than the repository root unless using an importable module install; bundled paths are resolved from module paths rather than assuming the current working directory for resources.

## Tests
Run:
```sh
python -m unittest discover -v
```
The test suite covers the tokenizer, parser, evaluator, WAV output, project persistence, presets, terminal width handling, layout and command registration, including security checks for dangerous Python expressions.

import json,os,tempfile
from dataclasses import dataclass,asdict
from pathlib import Path
from .constants import CONFIG_VERSION,SAMPLE_RATES
@dataclass
class Config:
 version:int=CONFIG_VERSION;theme:str="CYBER_CYAN";fps_limit:int=30;performance_mode:str="BALANCED";unicode_mode:bool=True;animations_enabled:bool=True;autosave_enabled:bool=True;default_sample_rate:int=8000;default_volume:int=80;default_duration:int=10;audio_backend:str="AUTO";confirm_exit:bool=True;debug_mode:bool=False
class ConfigManager:
 def __init__(self,path):self.path=Path(path);self.config=Config()
 def load(self):
  if not self.path.exists():return self.config
  try:d=json.loads(self.path.read_text(encoding="utf-8")); d["version"]=CONFIG_VERSION;self.config=Config(**{k:v for k,v in d.items() if k in Config.__dataclass_fields__});return self.config
  except Exception:
   try:os.replace(self.path,self.path.with_suffix(".json.broken"))
   except OSError:pass
   self.config=Config();return self.config
 def save(self):
  self.path.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(prefix="cfg-",dir=self.path.parent)
  try:
   with os.fdopen(fd,"w",encoding="utf-8") as f:json.dump(asdict(self.config),f,indent=2);f.flush();os.fsync(f.fileno())
   os.replace(tmp,self.path)
  finally:
   if os.path.exists(tmp):os.unlink(tmp)

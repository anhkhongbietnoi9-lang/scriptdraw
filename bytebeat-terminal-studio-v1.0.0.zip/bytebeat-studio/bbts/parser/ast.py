from dataclasses import dataclass

class Node:
    def evaluate(self, ctx):
        raise NotImplementedError

@dataclass(frozen=True)
class NumberNode(Node):
    value: int | float
    def evaluate(self, ctx): return self.value

@dataclass(frozen=True)
class VariableNode(Node):
    name: str
    def evaluate(self, ctx): return ctx[self.name]

@dataclass(frozen=True)
class UnaryNode(Node):
    op: str
    operand: Node
    def evaluate(self, ctx):
        v = self.operand.evaluate(ctx)
        if self.op == "+": return +v
        if self.op == "-": return -v
        if self.op == "~": return ~int(v)
        raise ValueError("UNSUPPORTED OPERATOR")

@dataclass(frozen=True)
class BinaryNode(Node):
    op: str
    left: Node
    right: Node
    def evaluate(self, ctx):
        a, b = self.left.evaluate(ctx), self.right.evaluate(ctx)
        if self.op == "+": return a+b
        if self.op == "-": return a-b
        if self.op == "*": return a*b
        if self.op == "/": return 0 if b == 0 else a/b
        if self.op == "%": return 0 if b == 0 else a%b
        if self.op == ">>": return int(a) >> max(0, int(b))
        if self.op == "<<": return int(a) << max(0, int(b))
        if self.op == "&": return int(a) & int(b)
        if self.op == "|": return int(a) | int(b)
        if self.op == "^": return int(a) ^ int(b)
        if self.op == ">": return int(a > b)
        if self.op == "<": return int(a < b)
        if self.op == ">=": return int(a >= b)
        if self.op == "<=": return int(a <= b)
        if self.op == "==": return int(a == b)
        if self.op == "!=": return int(a != b)
        if self.op == "&&": return int(bool(a) and bool(b))
        if self.op == "||": return int(bool(a) or bool(b))
        raise ValueError("UNSUPPORTED OPERATOR")

@dataclass(frozen=True)
class ConditionalNode(Node):
    condition: Node
    when_true: Node
    when_false: Node
    def evaluate(self, ctx):
        return self.when_true.evaluate(ctx) if self.condition.evaluate(ctx) else self.when_false.evaluate(ctx)

@dataclass(frozen=True)
class FunctionCallNode(Node):
    name: str
    args: tuple[Node, ...]
    def evaluate(self, ctx):
        return ctx["__funcs__"][self.name](*[a.evaluate(ctx) for a in self.args])

from .tokenizer import Token,BytebeatTokenizer,LexerError
from .ast import *
class ParseError(ValueError):
 def __init__(self,message,token): super().__init__(f"SYNTAX ERROR: {message} at position {token.position} (line {token.line}, column {token.column})"); self.message=message; self.token=token
class BytebeatParser:
 def __init__(self): self.tokens=[]; self.i=0; self.node_count=0
 def parse(self,source): self.tokens=BytebeatTokenizer().tokenize(source); self.i=0; self.node_count=0; n=self.conditional(); self.expect("EOF"); return n
 def cur(self):return self.tokens[self.i]
 def eat(self):t=self.cur();self.i+=1;return t
 def accept(self,v):
  if self.cur().value==v:return self.eat()
  return None
 def expect(self,v):
  t=self.cur()
  if t.value!=v and not(v=="EOF" and t.kind=="EOF"):raise ParseError(f"Unexpected token: {t.value or '<EOF>'}, expected {v}",t)
  return self.eat()
 def node(self,n):
  self.node_count+=1
  if self.node_count>4096:raise ParseError("EXPRESSION TOO COMPLEX",self.cur())
  return n
 def chain(self,sub,ops):
  n=sub()
  while self.cur().value in ops:
   op=self.eat().value; r=sub(); n=self.node(BinaryNode(op,n,r))
  return n
 def conditional(self):
  n=self.logical_or()
  if self.accept("?"): a=self.conditional(); self.expect(":"); b=self.conditional(); n=self.node(ConditionalNode(n,a,b))
  return n
 def logical_or(self):return self.chain(self.logical_and,{"||"})
 def logical_and(self):return self.chain(self.bit_or,{"&&"})
 def bit_or(self):return self.chain(self.bit_xor,{"|"})
 def bit_xor(self):return self.chain(self.bit_and,{"^"})
 def bit_and(self):return self.chain(self.equality,{"&"})
 def equality(self):return self.chain(self.comparison,{"==","!="})
 def comparison(self):return self.chain(self.shift,{">","<",">=","<="})
 def shift(self):return self.chain(self.additive,{">>","<<"})
 def additive(self):return self.chain(self.multiplicative,{"+","-"})
 def multiplicative(self):return self.chain(self.unary,{"*","/","%"})
 def unary(self):
  if self.cur().value in {"+","-","~"}: return self.node(UnaryNode(self.eat().value,self.unary()))
  return self.primary()
 def primary(self):
  t=self.cur()
  if t.kind=="NUMBER": self.eat(); return self.node(NumberNode(float(t.value) if "." in t.value else int(t.value)))
  if t.kind=="IDENT":
   self.eat(); name=t.value
   if self.accept("("):
    args=[]
    if self.cur().value!=")":
     while True:
      args.append(self.conditional())
      if not self.accept(","):break
    self.expect(")"); return self.node(FunctionCallNode(name,tuple(args)))
   return self.node(VariableNode(name))
  if self.accept("("):
   n=self.conditional(); self.expect(")"); return n
  raise ParseError(f"Unexpected token: {t.value or '<EOF>'}",t)

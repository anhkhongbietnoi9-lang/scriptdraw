from dataclasses import dataclass
import re
@dataclass(frozen=True)
class Token: kind:str; value:str; position:int; line:int; column:int
class LexerError(ValueError): pass
OPS=sorted([">>","<<",">=","<=","==","!=","&&","||","+","-","*","/","%","&","|","^","~",">","<","?",":","(",")",","],key=len,reverse=True)
OPSET=set(OPS)
class BytebeatTokenizer:
 def tokenize(self,source):
  if len(source)>8192: raise LexerError("EXPRESSION TOO COMPLEX: max length is 8192 chars")
  out=[]; i=0; line=1; col=1
  while i<len(source):
   c=source[i]
   if c.isspace():
    if c=="\n":line+=1;col=1
    else:col+=1
    i+=1;continue
   pos=i
   if c.isdigit() or c==".":
    m=re.match(r"(?:\d+(?:\.\d*)?|\.\d+)",source[i:])
    if not m: raise LexerError(f"INVALID NUMBER at position {i}")
    v=m.group(0); out.append(Token("NUMBER",v,i,line,col)); i+=len(v); col+=len(v);continue
   if c.isalpha() or c=="_":
    m=re.match(r"[A-Za-z_][A-Za-z0-9_]*",source[i:]); v=m.group(0); out.append(Token("IDENT",v,i,line,col)); i+=len(v); col+=len(v);continue
   op=next((o for o in OPS if source.startswith(o,i)),None)
   if op:
    kind="PUNC" if op in "(),?:" else "OP"; out.append(Token(kind,op,i,line,col)); i+=len(op);col+=len(op);continue
   raise LexerError(f"INVALID CHARACTER {c!r} at position {i} (line {line}, column {col})")
  out.append(Token("EOF","",len(source),line,col)); return out

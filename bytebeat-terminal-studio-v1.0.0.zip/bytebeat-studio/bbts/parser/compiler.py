import math
from .ast import *
from .parser import BytebeatParser
SAFE_FUNCTIONS={"abs":abs,"min":min,"max":max,"int":int,"floor":math.floor,"ceil":math.ceil,"sqrt":math.sqrt,"sin":math.sin,"cos":math.cos,"pow":pow,"clamp":lambda x,a,b:max(a,min(b,x))}
ALLOWED_VARS={"t"}
class SemanticError(ValueError):pass
class CompiledExpression:
 def __init__(self,source,ast): self.source=source; self.ast=ast
 def sample(self,t): return self.ast.evaluate({"t":t,"__funcs__":SAFE_FUNCTIONS})
def validate(node):
 if isinstance(node,VariableNode):
  if node.name not in ALLOWED_VARS:raise SemanticError(f"UNKNOWN IDENTIFIER: {node.name}")
 elif isinstance(node,NumberNode):pass
 elif isinstance(node,UnaryNode):validate(node.operand)
 elif isinstance(node,BinaryNode):validate(node.left);validate(node.right)
 elif isinstance(node,ConditionalNode):validate(node.condition);validate(node.when_true);validate(node.when_false)
 elif isinstance(node,FunctionCallNode):
  if node.name not in SAFE_FUNCTIONS:raise SemanticError(f"UNKNOWN OR UNSAFE FUNCTION: {node.name}")
  if node.name in {"abs","min","max","int","floor","ceil","sqrt","sin","cos","pow","clamp"}:pass
  for a in node.args:validate(a)
 else:raise SemanticError("UNSUPPORTED AST NODE")
class BytebeatCompiler:
 def compile(self,source):
  ast=BytebeatParser().parse(source); validate(ast); return CompiledExpression(source,ast)

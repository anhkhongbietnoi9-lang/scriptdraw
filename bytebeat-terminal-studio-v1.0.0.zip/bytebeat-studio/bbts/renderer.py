from .terminal import visible_width, pad_to_width, truncate_to_width

class Renderer:
    def __init__(self, term, theme):
        self.term = term
        self.theme = theme
        self.last = []
    def style(self, text, code, bold=False):
        return f"\x1b[{1 if bold else 0};{code}m{text}\x1b[0m"
    def box(self, rect, title, lines, active=False):
        x,y,w,h=rect.x,rect.y,rect.width,rect.height
        tl,tr,bl,br,v,hh=("╔","╗","╚","╝","║","═")
        out=[(x,y,tl+hh*max(0,w-2)+tr)]
        title_text=truncate_to_width(" "+title+" ",max(0,w-2))
        out.append((x,y+1,v+self.style(pad_to_width(title_text,max(0,w-2)),self.theme.theme.accent if active else self.theme.theme.primary,True)+v))
        for i in range(max(0,h-3)):
            line=lines[i] if i<len(lines) else ""
            out.append((x,y+2+i,v+pad_to_width(truncate_to_width(line,max(0,w-2)),max(0,w-2))+v))
        out.append((x,y+h-1,bl+hh*max(0,w-2)+br))
        return out
    def _screen_lines(self,state,w,h):
        lines=["╔"+"═"*max(0,w-2)+"╗"]+["║"+pad_to_width(" BYTEBEAT TERMINAL STUDIO  "+state.active_screen.upper(),max(0,w-2))+"║"]+["╠"+"═"*max(0,w-2)+"╣"]
        if state.active_screen=="help":
            items=[f"{c.shortcut:<12} {c.label:<18} {c.description}" for c in self.registry.all()]
        else:
            items=["T  Theme: cycle theme","F  Performance: PERFORMANCE / BALANCED / BATTERY","U  Unicode / ASCII mode","M  Animations on/off","B  Audio backend","A  Auto preview on/off","L  Loop on/off","Ctrl+S  Save settings","ESC  Back"]
        start=max(0,getattr(state,"active_panel",0)); view=items[start:start+max(1,h-6)]
        lines.extend("║"+pad_to_width(truncate_to_width(x,max(0,w-2)),max(0,w-2))+"║" for x in view)
        lines.append("╚"+"═"*max(0,w-2)+"╝")
        return [pad_to_width(x,w)[:w] for x in lines[:h]]

    def render(self,state,layout,visual_lines,editor_text,notifs):
        size=self.term.size();w,h=size.width,size.height
        if getattr(state,"active_screen","") in {"help","settings"}:
            self.term.write("\x1b[H" + "\n".join(self._screen_lines(state,w,h))); self.term.flush(); return
        frame=[" "*w for _ in range(h)]
        def put(x,y,s):
            if not(1<=y<=h): return
            s=truncate_to_width(s,max(0,w-x+1)); row=frame[y-1]
            frame[y-1]=row[:x-1]+s+row[x-1+visible_width(s):]
        put(1,1,f" {state.project_name}{'*' if state.project_dirty else ''}  BBTS v1.0.0  {state.playback_state.value}")
        def panel(rect,title,lines):
            for x,y,s in self.box(rect,title,lines,True): put(x,y,s)
        panel(layout.visualizer,"VISUALIZER",visual_lines)
        status="● VALID" if state.expression_valid else "× INVALID: "+truncate_to_width(state.expression_error,max(1,layout.editor.width-14))
        expr_view=truncate_to_width(editor_text if state.active_screen=="editor" else state.expression,max(1,layout.editor.width-4))
        panel(layout.editor,"EXPRESSION",["> "+expr_view,status])
        panel(layout.parameters,"PARAMETERS",[f"BPM          {state.bpm}",f"VOLUME       {state.volume}%",f"DURATION     {state.duration}s",f"SAMPLE RATE  {state.sample_rate} Hz","CHANNELS     MONO","BIT DEPTH    8-bit"])
        total=max(1,state.total_samples);secs=state.sample_position/state.sample_rate; pct=100*state.sample_position/total
        panel(layout.engine,"ENGINE",[f"STATE        {state.playback_state.value}",f"POSITION     {state.sample_position} / {total}",f"PROGRESS     {pct:5.1f}%",f"TIME         {secs:05.2f}s / {state.duration:05.2f}s",f"RATE         {state.sample_rate} Hz",f"BACKEND      {state.audio_backend_name}"])
        footer="[ENTER] PLAY/RESUME [SPACE] PAUSE [S] STOP [R] RESET [E] EDIT [P] PRESETS [V] VISUALIZER [W] EXPORT [O] SETTINGS [Q] QUIT"
        put(1,h-1,footer);put(1,h,notifs[-1] if notifs else state.status_message)
        self.term.write("\x1b[H" + "\n".join(frame)); self.term.flush()

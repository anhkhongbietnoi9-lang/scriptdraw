from pathlib import Path
APP_NAME = "BYTEBEAT TERMINAL STUDIO"
APP_SHORT = "BBTS"
APP_VERSION = "1.0.0"
SCHEMA_VERSION = 1
CONFIG_VERSION = 1
MIN_WIDTH, MIN_HEIGHT = 52, 18
CACHE_LIMIT_BYTES = 64 * 1024 * 1024
SAMPLE_RATES = (8000, 11025, 16000, 22050, 32000, 44100, 48000)
DURATIONS = (1, 2, 5, 10, 15, 30, 60, 120)
DEFAULT_EXPRESSION = "(t*(t>>5|t>>8))>>(t>>16)"

# Exact user-provided branding string. Do not format, strip, or normalize it.
SPLASH_SKULL = r"""          .__,^._
     .:if$^°4$.,d$%?:.
   .:is$?    j?i$7p$'   .
  -iIS$?b,..¬$:i?'%?\   :
 iIS$S?·'°?Z?'  .ª:   •  •,L._
-iI$SIi:-  s$' '¬  .   \,ds$$$k.
:IS$S?Ii:-$7-:u,dL,_,dss$?ª','
:IS$$SIi:j?   '°4fI??ZS$?° .'
-iSS$$SIj$i-. .:.'?$$?'  .
-:?S$$$IS$?-ji:-.  
-:?S$$$$Sii?`¨..:-
    -::?SS$Si7-:::·`
      '::i??i;;-·'
        ---..."""

UNICODE_GLYPHS={"tl":"┌","tr":"┐","bl":"└","br":"┘","v":"│","h":"─","dtl":"╔","dtr":"╗","dbl":"╚","dbr":"╝","dv":"║","dh":"═","wave":"▁▂▃▄▅▆▇█","ok":"✓","err":"×","dot":"●","stop":"■","pause":"Ⅱ"}
ASCII_GLYPHS={"tl":"+","tr":"+","bl":"+","br":"+","v":"|","h":"-","dtl":"+","dtr":"+","dbl":"+","dbr":"+","dv":"|","dh":"=","wave":"._-*#%","ok":"+","err":"x","dot":"o","stop":"#","pause":"||"}
from dataclasses import dataclass
@dataclass
class Command:
 id:str;label:str;shortcut:str;description:str;enabled:object;handler:object
class CommandRegistry:
 def __init__(self):self.items={}
 def register(self,c):self.items[c.id]=c
 def get(self,k):return self.items[k]
 def all(self):return list(self.items.values())

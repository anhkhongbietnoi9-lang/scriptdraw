from collections import deque
from .state import Notification,NotificationLevel
class NotificationManager:
 def __init__(self,max_items=8): self.items=deque(maxlen=max_items)
 def push(self,level,message,duration=2.5): self.items.append(Notification(level,message,duration))
 def info(self,m): self.push(NotificationLevel.INFO,m)
 def success(self,m): self.push(NotificationLevel.SUCCESS,m)
 def warning(self,m): self.push(NotificationLevel.WARNING,m,3.5)
 def error(self,m): self.push(NotificationLevel.ERROR,m,5.0)
 def active(self):
  while self.items and self.items[0].expired:self.items.popleft()
  return list(self.items)
 def latest(self):
  a=self.active(); return a[-1].message if a else "READY"

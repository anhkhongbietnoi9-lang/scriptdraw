import json
from dataclasses import dataclass,asdict
from pathlib import Path
from ..parser.compiler import BytebeatCompiler
@dataclass(frozen=True)
class Preset:
 id:str;name:str;expression:str;category:str;description:str;recommended_sample_rate:int;recommended_duration:int;builtin:bool=True
BUILTINS=[
 Preset("classic","Classic","(t*(t>>5|t>>8))>>(t>>16)","Classic","Crunchy canonical bytebeat texture.",8000,10),
 Preset("robot","Robot","(t*(t>>7|t>>9))>>(t>>11)","Robotic","Rhythmic metallic pulse texture.",8000,10),
 Preset("space","Space","(t*5&t>>7)|(t*3&t>>10)","Space","Layered drifting digital tones.",8000,10),
 Preset("glitch","Glitch","((t>>4)|(t*5))*(t>>7|t>>9)","Glitch","Harsh rapidly changing digital grit.",8000,8),
 Preset("acid","Acid","(t*9&t>>4)|(t*5&t>>7)|(t*3&t>>10)","Acid","Fast acidic layered bytebeat motion.",8000,10),
 Preset("pulse","Pulse","(t>>4|t*3)&(t>>7|t*5)","Pulse","Compact repeating pulse pattern.",8000,10),
 Preset("tunnel","Tunnel","(t*3&t>>9)|(t*5&t>>13)","Tunnel","Deep repeated tunnel-like pattern.",11025,8),
 Preset("industrial","Industrial","(t*(t>>4|t>>7))&(t>>9)","Industrial","Dense mechanical digital rhythm.",8000,8),
 Preset("ambient","Ambient","((t>>5)|(t*7))&(t>>8)","Ambient","Soft evolving arithmetic texture.",8000,12),
 Preset("noise","Noise","t*(t>>3|t>>5)","Noise","Broadband arithmetic noise texture.",8000,6),
 Preset("arcade","Arcade","(t*11&t>>5)|(t*7&t>>9)","Arcade","Bright game-like square-bit motion.",11025,8),
]
class PresetManager:
 def __init__(self,path,compiler):self.path=Path(path);self.compiler=compiler;self.custom=self._load_custom()
 def _load_custom(self):
  if not self.path.exists():return []
  try:return [Preset(**x) for x in json.loads(self.path.read_text(encoding="utf-8"))]
  except Exception:return []
 def _save(self):self.path.parent.mkdir(parents=True,exist_ok=True);self.path.write_text(json.dumps([asdict(x) for x in self.custom],ensure_ascii=False,indent=2),encoding="utf-8")
 def list(self,query=""):
  allp=BUILTINS+self.custom; q=query.lower();return [p for p in allp if not q or q in p.name.lower() or q in p.category.lower() or q in p.description.lower()]
 def get(self,pid):return next((p for p in BUILTINS+self.custom if p.id==pid),None)
 def create(self,name,category,description,expression):
  self.compiler.compile(expression); pid="custom-"+str(abs(hash((name,expression))))
  p=Preset(pid,name,expression,category,description,8000,10,False);self.custom.append(p);self._save();return p
 def delete(self,pid):
  p=self.get(pid)
  if not p or p.builtin:raise ValueError("DELETE DISABLED FOR SYSTEM PRESET")
  self.custom=[x for x in self.custom if x.id!=pid];self._save()

import json,os,tempfile
from pathlib import Path
from datetime import datetime,timezone
from .model import Project
from ..constants import SCHEMA_VERSION
class ProjectManager:
 def __init__(self,root):self.root=Path(root);self.projects=self.root/"projects";self.exports=self.root/"exports";self.presets=self.root/"presets";self.logs=self.root/"logs";self.cache=self.root/"cache"; [p.mkdir(parents=True,exist_ok=True) for p in (self.root,self.projects,self.exports,self.presets,self.logs,self.cache)]
 def _atomic_json(self,path,data):
  path=Path(path);path.parent.mkdir(parents=True,exist_ok=True); fd,tmp=tempfile.mkstemp(prefix=".bbts-",suffix=".tmp",dir=path.parent)
  try:
   with os.fdopen(fd,"w",encoding="utf-8") as f:json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
   os.replace(tmp,path)
  finally:
   if os.path.exists(tmp):os.unlink(tmp)
 def save(self,p,path):
  p.modified_at=datetime.now(timezone.utc).isoformat(); self._atomic_json(path,p.to_dict())
 def load(self,path):
  try:d=json.loads(Path(path).read_text(encoding="utf-8"))
  except json.JSONDecodeError as e:raise ValueError("PROJECT FILE CORRUPTED: invalid JSON") from e
  v=int(d.get("schema_version",0))
  if v>SCHEMA_VERSION:raise ValueError("UNSUPPORTED PROJECT VERSION")
  if v<SCHEMA_VERSION:d["schema_version"]=SCHEMA_VERSION
  return Project.from_dict(d)

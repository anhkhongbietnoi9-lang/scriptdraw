from dataclasses import dataclass,asdict
from datetime import datetime,timezone
from . import __name__
from ..constants import SCHEMA_VERSION,DEFAULT_EXPRESSION
@dataclass
class Project:
 schema_version:int=SCHEMA_VERSION; project_name:str="Untitled"; expression:str=DEFAULT_EXPRESSION; bpm:int=120; volume:int=80; duration:int=10; sample_rate:int=8000; channels:int=1; bit_depth:int=8; visualizer_mode:str="WAVE"; visualizer_zoom:float=1.; theme:str="CYBER_CYAN"; loop_enabled:bool=False; auto_preview:bool=False; created_at:str=""; modified_at:str=""
 def __post_init__(self):
  now=datetime.now(timezone.utc).isoformat()
  if not self.created_at:self.created_at=now
  if not self.modified_at:self.modified_at=now
 def to_dict(self):return asdict(self)
 @classmethod
 def from_dict(cls,d):
  req={"schema_version","project_name","expression","bpm","volume","duration","sample_rate","channels","bit_depth","visualizer_mode","visualizer_zoom","theme","loop_enabled","auto_preview"}
  if not req.issubset(d):raise ValueError("PROJECT SCHEMA ERROR: missing fields")
  return cls(**{k:d[k] for k in cls.__dataclass_fields__ if k in d})

def wave(samples,width,height,unicode=True,seed=0):
 glyph="▁▂▃▄▅▆▇█" if unicode else "._-*#%@";width=max(1,width); vals=samples or [128];out=[]
 for row in range(height):out.append("".ljust(width))
 if not samples:return [" NO SIGNAL".ljust(width)][:height]
 cols=[]; step=max(1,len(vals)//width)
 for i in range(width):
  a=vals[i*step:min(len(vals),(i+1)*step)] or [128]; m=sum(a)/len(a); lvl=max(0,min(len(glyph)-1,int((m/255)*(len(glyph)-1))));cols.append(glyph[lvl])
 return ["".join(cols)[:width]]+["".ljust(width) for _ in range(max(0,height-1))]

import cmath,math
def _fft(a):
 n=len(a)
 if n==1:return a
 even=_fft(a[0::2]);odd=_fft(a[1::2]);out=[0j]*n
 for k in range(n//2):
  t=cmath.exp(-2j*math.pi*k/n)*odd[k];out[k]=even[k]+t;out[k+n//2]=even[k]-t
 return out
def spectrum(samples,width,height,unicode=True,seed=0):
 if not samples:return [" NO SIGNAL".ljust(width)][:height]
 n=1
 while n*2<=min(1024,len(samples),max(64,width*16)):n*=2
 vals=[(x-128)/128 for x in samples[-n:]];vals += [0]*(n-len(vals));vals=[v*(0.5-0.5*math.cos(2*math.pi*i/(n-1))) for i,v in enumerate(vals)]
 mags=[abs(x)/n for x in _fft(vals)[:n//2]]; step=max(1,len(mags)//width); cols=[]
 for i in range(width):
  chunk=mags[i*step:min(len(mags),(i+1)*step)] or [0];m=max(chunk);lvl=math.log10(1+500*m)/math.log10(501);cols.append(lvl)
 block="█" if unicode else "#";return ["".join(block if v>=r/height else " " for v in cols) for r in range(height,0,-1)]

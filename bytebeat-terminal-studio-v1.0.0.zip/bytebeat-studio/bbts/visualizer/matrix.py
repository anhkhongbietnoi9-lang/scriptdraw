def matrix(samples,width,height,unicode=True,seed=0):
 chars="01";seed=(seed+1)%1000000;rows=[]
 for y in range(height): rows.append("".join(chars[(seed+x*7+y*11)%2] for x in range(width)))
 return rows

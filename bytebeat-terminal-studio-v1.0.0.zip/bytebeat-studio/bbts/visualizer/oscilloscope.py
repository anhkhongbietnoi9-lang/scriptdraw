def oscilloscope(samples,width,height,unicode=True,seed=0):
 if not samples:return [" NO SIGNAL".ljust(width)][:height]
 grid=[[" "]*width for _ in range(height)];mid=height//2;step=max(1,len(samples)//width)
 for x in range(width):
  vals=samples[x*step:min(len(samples),(x+1)*step)] or [128];v=sum(vals)/len(vals);y=max(0,min(height-1,int(mid-(v-128)/128*max(1,mid-1))))
  grid[y][x]="•" if unicode else "*"
 return ["".join(r) for r in grid]

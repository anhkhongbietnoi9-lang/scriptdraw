def bars(samples,width,height,unicode=True,seed=0):
 if not samples:return [" NO SIGNAL".ljust(width)][:height]
 block="█" if unicode else "#"; step=max(1,len(samples)//width); vals=[]
 for i in range(width):
  chunk=samples[i*step:min(len(samples),(i+1)*step)] or [128];vals.append(max(abs(x-128) for x in chunk)/127)
 rows=[]
 for r in range(height,0,-1):rows.append("".join(block if v>=r/height else " " for v in vals))
 return rows

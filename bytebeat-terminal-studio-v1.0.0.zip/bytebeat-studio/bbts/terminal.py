from dataclasses import dataclass
import os,select,shutil,sys,termios,tty,time,re,unicodedata
from .state import KeyEvent

ESC="\x1b"; CSI=ESC+"["; RESET=CSI+"0m"; BOLD=CSI+"1m"; DIM=CSI+"2m"; CLEAR_SCREEN=CSI+"2J"; CLEAR_LINE=CSI+"2K"; CURSOR_HOME=CSI+"H"; CURSOR_HIDE=CSI+"?25l"; CURSOR_SHOW=CSI+"?25h"; ALT_SCREEN_ON=CSI+"?1049h"; ALT_SCREEN_OFF=CSI+"?1049l"
ANSI_RE=re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
@dataclass(frozen=True)
class TerminalSize: width:int; height:int

def visible_width(text):
 text=ANSI_RE.sub("",text); return sum(2 if unicodedata.east_asian_width(c) in "WFA" else 0 if unicodedata.combining(c) else 1 for c in text)
def truncate_to_width(text,width):
 if width<=0:return ""
 out=""; w=0
 for c in text:
  cw=2 if unicodedata.east_asian_width(c) in "WFA" else 0 if unicodedata.combining(c) else 1
  if w+cw>width: break
  out+=c; w+=cw
 return out
def pad_to_width(text,width): return text+" "*max(0,width-visible_width(text))
def center_text(text,width): return " "*max(0,(width-visible_width(text))//2)+text
class Terminal:
 def __init__(self,stdin=None,stdout=None): self.stdin=stdin or sys.stdin; self.stdout=stdout or sys.stdout; self._saved=None; self._raw=False; self._alt=False
 def size(self):
  try: s=shutil.get_terminal_size((80,24)); return TerminalSize(s.columns,s.lines)
  except OSError:return TerminalSize(80,24)
 def write(self,text): self.stdout.write(text)
 def flush(self): self.stdout.flush()
 def clear(self): self.write(CLEAR_SCREEN+CURSOR_HOME)
 def move(self,x,y): self.write(f"{CSI}{max(1,y)};{max(1,x)}H")
 def hide_cursor(self): self.write(CURSOR_HIDE)
 def show_cursor(self): self.write(CURSOR_SHOW)
 def alt_screen(self,on=True): self.write(ALT_SCREEN_ON if on else ALT_SCREEN_OFF); self._alt=on
 def enter_raw(self):
  if not self.stdin.isatty(): raise RuntimeError("INTERACTIVE TERMINAL REQUIRED")
  self._saved=termios.tcgetattr(self.stdin.fileno()); tty.setcbreak(self.stdin.fileno()); self._raw=True; self.write(CURSOR_HIDE); self.flush()
 def restore(self):
  if self._saved is not None:
   try: termios.tcsetattr(self.stdin.fileno(),termios.TCSADRAIN,self._saved)
   except Exception: pass
   self._saved=None
  self._raw=False
  if self._alt:self.alt_screen(False)
  self.show_cursor(); self.flush()
 def poll(self,timeout=0.0):
  if not self._raw:return []
  try: ready,_,_=select.select([self.stdin],[],[],timeout)
  except (OSError,ValueError): return []
  return [self._read_key()] if ready else []
 def _read_key(self):
  ch=self.stdin.read(1)
  if ch!=ESC:return KeyEvent("CTRL_C",ch,ctrl=True) if ch=="\x03" else KeyEvent(ch.upper() if ch.isprintable() else ch,ch)
  # distinguish literal ESC from CSI sequence
  try:
   ready,_,_=select.select([self.stdin],[],[],0.025)
   if not ready:return KeyEvent("ESC")
   nxt=self.stdin.read(1)
   if nxt!="[": return KeyEvent("ESC")
   seq=""
   for _ in range(8):
    ready,_,_=select.select([self.stdin],[],[],0.01)
    if not ready:break
    c=self.stdin.read(1); seq+=c
    if c.isalpha() or c=="~":break
  except Exception:return KeyEvent("ESC")
  return {"A":KeyEvent("UP"),"B":KeyEvent("DOWN"),"C":KeyEvent("RIGHT"),"D":KeyEvent("LEFT"),"H":KeyEvent("HOME"),"F":KeyEvent("END"),"3~":KeyEvent("DELETE"),"5~":KeyEvent("PAGEUP"),"6~":KeyEvent("PAGEDOWN")}.get(seq,KeyEvent("ESC"))

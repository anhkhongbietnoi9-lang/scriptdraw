import threading,time,queue
from dataclasses import dataclass
from .backends import BackendError
@dataclass(frozen=True)
class PlaybackEvent:
 kind:str; position:int=0; message:str=""
class PlaybackController:
 def __init__(self,engine,backend,cache_dir,event_queue):
  self.engine=engine;self.backend=backend;self.cache_dir=cache_dir;self.events=event_queue;self.stop_event=threading.Event();self.worker=None;self.started_at=0.;self.paused_at=0.;self.path=None;self.snapshot=None;self.position=0
 def start(self,snapshot,compiled):
  if self.worker and self.worker.is_alive():
   if self.paused_at:self.resume()
   return
  self.stop_event.clear();self.snapshot=snapshot;self.position=0
  self.worker=threading.Thread(target=self._worker,args=(snapshot,compiled),name="bbts-playback",daemon=True);self.worker.start()
 def _worker(self,snapshot,compiled):
  from pathlib import Path
  self.events.put(PlaybackEvent("LOADING"))
  try:
   self.cache_dir.mkdir(parents=True,exist_ok=True); self.path=self.cache_dir/(self.engine.cache_key(snapshot)+".wav")
   if not self.path.exists(): self.engine.generate_wav(snapshot,compiled,self.path,self.stop_event)
   if self.stop_event.is_set():return
   self.backend.play(self.path); self.started_at=time.monotonic(); self.events.put(PlaybackEvent("PLAYING"))
   while not self.stop_event.is_set():
    if self.paused_at:
     time.sleep(.05);continue
    elapsed=max(0,time.monotonic()-self.started_at); self.position=min(snapshot.total_samples,int(elapsed*snapshot.sample_rate));self.events.put(PlaybackEvent("POSITION",self.position))
    if self.position>=snapshot.total_samples:
     if snapshot.loop:
      try:self.backend.play(self.path)
      except Exception:pass
      self.started_at=time.monotonic();self.position=0;continue
     self.events.put(PlaybackEvent("FINISHED",snapshot.total_samples));break
    time.sleep(.05)
  except Exception as e:self.events.put(PlaybackEvent("ERROR",self.position,str(e)))
 def pause(self):
  if not self.worker or not self.worker.is_alive():return False
  self.backend.pause(); self.paused_at=time.monotonic();self.events.put(PlaybackEvent("PAUSED",self.position));return True
 def resume(self):
  if not self.paused_at:return False
  self.backend.resume(); paused=self.paused_at; self.started_at += time.monotonic()-paused; self.paused_at=0.;self.events.put(PlaybackEvent("PLAYING",self.position));return True
 def stop(self):
  self.stop_event.set()
  try:self.backend.stop()
  except Exception:pass
  if self.worker and self.worker is not threading.current_thread():self.worker.join(timeout=.8)
  self.worker=None;self.paused_at=0.;self.position=0

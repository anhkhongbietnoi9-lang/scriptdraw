import wave
from pathlib import Path
def write_wav_stream(path,sample_rate,chunks,channels=1,bit_depth=8):
 if channels!=1 or bit_depth!=8:raise ValueError("Only 8-bit mono PCM is implemented")
 path=Path(path)
 with wave.open(str(path),"wb") as w:
  w.setnchannels(1);w.setsampwidth(1);w.setframerate(sample_rate);w.setcomptype("NONE","not compressed")
  for chunk in chunks:w.writeframes(chunk)
def wav_bytes(samples,sample_rate):
 import io
 b=io.BytesIO()
 with wave.open(b,"wb") as w:w.setnchannels(1);w.setsampwidth(1);w.setframerate(sample_rate);w.writeframes(samples)
 return b.getvalue()
def verify_wav(path,expected_rate,expected_frames):
 with wave.open(str(path),"rb") as w:
  return w.getnchannels()==1 and w.getsampwidth()==1 and w.getframerate()==expected_rate and w.getnframes()==expected_frames

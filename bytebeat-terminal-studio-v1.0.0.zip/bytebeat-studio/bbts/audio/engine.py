from dataclasses import dataclass
from hashlib import sha256
from .wav import wav_bytes
@dataclass(frozen=True)
class EngineSnapshot:
 expression:str; sample_rate:int; duration:int; volume:int; channels:int=1; bit_depth:int=8; loop:bool=False
 @property
 def total_samples(self): return self.sample_rate*self.duration
class BytebeatEngine:
 def __init__(self,compiler): self.compiler=compiler; self._cache={}
 def compile(self,expr):
  if expr not in self._cache:self._cache[expr]=self.compiler.compile(expr)
  return self._cache[expr]
 @staticmethod
 def sample_to_byte(value,volume):
  try:v=float(value)
  except (TypeError,ValueError):v=0
  u=int(v)&255; signed=u-128; scaled=max(-128,min(127,round(signed*(volume/100)))); return scaled+128
 def render_sample(self,compiled,t,volume):return self.sample_to_byte(compiled.sample(t),volume)
 def generate_chunk(self,compiled,start,count,volume):return bytes(self.render_sample(compiled,t,volume) for t in range(start,start+count))
 def generate_wav(self,snapshot,compiled,path,cancel_event=None,progress=None,chunk=4096):
  from .wav import write_wav_stream
  def gen():
   pos=0
   while pos<snapshot.total_samples:
    if cancel_event and cancel_event.is_set():return
    n=min(chunk,snapshot.total_samples-pos); data=self.generate_chunk(compiled,pos,n,snapshot.volume); pos+=n; yield data
    if progress:progress(pos,snapshot.total_samples)
  write_wav_stream(path,snapshot.sample_rate,gen(),snapshot.channels,snapshot.bit_depth)
 def cache_key(self,s):return sha256(f"{s.expression}0{s.sample_rate}0{s.duration}0{s.volume}0{s.bit_depth}0{s.channels}".encode()).hexdigest()

import shutil,subprocess
from enum import Enum
class BackendError(RuntimeError):pass
class BackendState(Enum): AVAILABLE="AVAILABLE";UNAVAILABLE="UNAVAILABLE";BROKEN="BROKEN"
class AudioBackend:
 name="NONE"
 def is_available(self):return False
 def play(self,path=None):raise BackendError("AUDIO BACKEND UNAVAILABLE")
 def pause(self):raise BackendError("AUDIO BACKEND UNAVAILABLE")
 def resume(self):raise BackendError("AUDIO BACKEND UNAVAILABLE")
 def stop(self):return False
 def info(self):return "UNAVAILABLE"
 def cleanup(self):pass
 def _run(self,args):return subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,check=False)
class NoAudioBackend(AudioBackend):name="NONE"
class TermuxMediaPlayerBackend(AudioBackend):
 name="TERMUX_MEDIA_PLAYER"
 def is_available(self):return shutil.which("termux-media-player") is not None
 def play(self,path=None):
  args=["termux-media-player","play"]+([str(path)] if path else []); r=self._run(args)
  if r.returncode:return self._fail(r.stderr or r.stdout)
  return True
 def pause(self):return self._cmd(["termux-media-player","pause"])
 def resume(self):return self._cmd(["termux-media-player","play"])
 def stop(self):return self._cmd(["termux-media-player","stop"],False)
 def info(self):
  r=self._run(["termux-media-player","info"]); return (r.stdout.strip() or r.stderr.strip() or "UNAVAILABLE") if r.returncode==0 else "UNAVAILABLE"
 def _cmd(self,args,fail=True):
  r=self._run(args)
  if fail and r.returncode:self._fail(r.stderr or r.stdout)
  return r.returncode==0
 def _fail(self,msg):raise BackendError(msg.strip() or "BACKEND COMMAND FAILED")
class CLIBackend(AudioBackend):
 command=""; play_args=()
 def is_available(self):return shutil.which(self.command) is not None
 def play(self,path=None):
  if not path:raise BackendError("FILE REQUIRED")
  try:
   if hasattr(self,"proc") and self.proc and self.proc.poll() is None:return True
   self.proc=subprocess.Popen([self.command,*self.play_args,str(path)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   return True
  except OSError as e:raise BackendError(str(e))
 def pause(self):
  return False
 def resume(self):return self.play(self.current_path) if getattr(self,"current_path",None) else False
 def stop(self):
  p=getattr(self,"proc",None)
  if p and p.poll() is None:
   p.terminate()
   try:p.wait(timeout=.5)
   except subprocess.TimeoutExpired:p.kill();p.wait()
  return True
 def cleanup(self):self.stop()
class FFplayBackend(CLIBackend):name="FFPLAY";command="ffplay";play_args=("-nodisp","-autoexit","-loglevel","quiet")
class MPVBackend(CLIBackend):name="MPV";command="mpv";play_args=("--no-video","--really-quiet")
class ALSAPlayBackend(CLIBackend):name="APLAY";command="aplay";play_args=("-q",)
class AudioBackendManager:
 def __init__(self): self.backends=[TermuxMediaPlayerBackend(),FFplayBackend(),MPVBackend(),ALSAPlayBackend(),NoAudioBackend()]; self.current=self.detect()
 def detect(self):
  for b in self.backends:
   if b.is_available():return b
  return self.backends[-1]
 def select(self,name):
  b=next((x for x in self.backends if x.name==name),None)
  if b is None or not b.is_available():raise BackendError(f"BACKEND NOT AVAILABLE: {name}")
  self.current=b;return b

from dataclasses import dataclass
@dataclass
class Editor:
 text:str="";cursor:int=0;scroll:int=0;history:list=None;redo_stack:list=None;max_history:int=100
 def __post_init__(self):self.history=[] if self.history is None else self.history;self.redo_stack=[] if self.redo_stack is None else self.redo_stack
 def _save(self):self.history.append(self.text);self.history=self.history[-self.max_history:];self.redo_stack.clear()
 def insert(self,s):self._save();self.text=self.text[:self.cursor]+s+self.text[self.cursor:];self.cursor+=len(s)
 def backspace(self):
  if self.cursor:self._save();self.text=self.text[:self.cursor-1]+self.text[self.cursor:];self.cursor-=1
 def delete(self):
  if self.cursor<len(self.text):self._save();self.text=self.text[:self.cursor]+self.text[self.cursor+1:]
 def left(self):self.cursor=max(0,self.cursor-1)
 def right(self):self.cursor=min(len(self.text),self.cursor+1)
 def home(self):self.cursor=0
 def end(self):self.cursor=len(self.text)
 def undo(self):
  if self.history:self.redo_stack.append(self.text);self.text=self.history.pop();self.cursor=min(self.cursor,len(self.text))
 def redo(self):
  if self.redo_stack:self.history.append(self.text);self.text=self.redo_stack.pop();self.cursor=min(self.cursor,len(self.text))
 def select_all(self):self.cursor=len(self.text)
 def visible(self,width):
  if width<=1:return ""
  if self.cursor<self.scroll:self.scroll=self.cursor
  if self.cursor>=self.scroll+width:self.scroll=max(0,self.cursor-width+1)
  return self.text[self.scroll:self.scroll+width]

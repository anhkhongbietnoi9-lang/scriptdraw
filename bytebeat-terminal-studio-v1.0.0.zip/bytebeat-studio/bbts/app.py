import logging,os,platform,signal,time as time_module,queue,sys
from pathlib import Path
from .constants import *
from .state import *
from .theme import ThemeManager
from .terminal import Terminal
from .layout import LayoutManager
from .renderer import Renderer
from .notifications import NotificationManager
from .config import ConfigManager
from .parser import BytebeatCompiler,SemanticError,ParseError,LexerError
from .audio.engine import BytebeatEngine
from .audio.backends import AudioBackendManager,BackendError
from .audio.playback import PlaybackController,PlaybackEvent
from .project.model import Project
from .project.manager import ProjectManager
from .project.presets import PresetManager
from .editor import Editor
from .visualizer.base import VisualizerEngine
from .commands import Command,CommandRegistry
class Application:
 def __init__(self):
  self.root=Path.home()/".bbts";self.pm=ProjectManager(self.root);self.cfgm=ConfigManager(self.root/"config.json");self.cfg=self.cfgm.load();self.term=Terminal();self.theme=ThemeManager(ThemeName(self.cfg.theme));self.layout=LayoutManager();self.renderer=Renderer(self.term,self.theme);self.note=NotificationManager();self.compiler=BytebeatCompiler();self.engine=BytebeatEngine(self.compiler);self.backend_mgr=AudioBackendManager();self.events=queue.Queue();self.playback=PlaybackController(self.engine,self.backend_mgr.current,self.pm.cache,self.events);self.visual=VisualizerEngine();self.editor=Editor(DEFAULT_EXPRESSION);self.state=ApplicationState(expression=DEFAULT_EXPRESSION,audio_backend_name=self.backend_mgr.current.name,fps_limit=self.cfg.fps_limit,performance_mode=PerformanceMode(self.cfg.performance_mode),unicode_mode=self.cfg.unicode_mode,animations_enabled=self.cfg.animations_enabled,autosave_enabled=self.cfg.autosave_enabled,sample_rate=self.cfg.default_sample_rate,volume=self.cfg.default_volume,duration=self.cfg.default_duration,theme=ThemeName(self.cfg.theme));self.state.recalc();self.presets=PresetManager(self.pm.presets/"custom.json",self.compiler);self.registry=CommandRegistry();self.renderer.registry=self.registry;self.running=False;self._last_size=None;self._last_render=0.
 def setup(self):self.state.compiled_expression=self.engine.compile(self.state.expression);self.state.expression_valid=True;self._register_commands();logging.basicConfig(filename=self.root/"logs"/"bbts.log",level=logging.DEBUG if self.cfg.debug_mode else logging.INFO,format="%(asctime)s %(levelname)s %(message)s");logging.info("startup python=%s platform=%s backend=%s",sys.version,platform.platform(),self.backend_mgr.current.name)
 def _register_commands(self):
  H={"NEW":self.new_project,"PLAY":self.play,"PAUSE":self.pause,"STOP":self.stop,"RESET":self.reset,"EDIT":self.enter_editor,"APPLY_EXPRESSION":self.apply_editor,"PRESETS":self.preset_cycle,"EXPORT_WAV":self.export_wav,"VISUALIZER_NEXT":self.next_visualizer,"ZOOM_IN":self.zoom_in,"ZOOM_OUT":self.zoom_out,"SETTINGS":self.settings,"HELP":self.help,"TOGGLE_LOOP":self.toggle_loop,"TOGGLE_AUTO_PREVIEW":self.toggle_autopreview,"QUIT":self.quit,"UNDO":self.editor.undo,"REDO":self.editor.redo}
  defs=[("NEW","NEW","N","Create a new project with default settings"),("PLAY","PLAY","ENTER","Play or resume playback"),("PAUSE","PAUSE","SPACE","Pause current playback"),("STOP","STOP","S","Stop playback and reset position"),("RESET","RESET","R","Reset playback position"),("EDIT","EDIT","E","Edit the active Bytebeat expression"),("PRESETS","PRESETS","P","Browse and load presets"),("EXPORT_WAV","EXPORT WAV","W","Export the current expression to a PCM WAV file"),("VISUALIZER_NEXT","VISUALIZER","V","Cycle the waveform visualizer"),("ZOOM_IN","ZOOM IN","+","Increase visualizer zoom"),("ZOOM_OUT","ZOOM OUT","-","Decrease visualizer zoom"),("SETTINGS","SETTINGS","O","Open application settings"),("HELP","HELP","?","Show commands from the registry"),("TOGGLE_LOOP","LOOP","L","Toggle playback looping"),("TOGGLE_AUTO_PREVIEW","AUTO PREVIEW","A","Toggle preset auto preview"),("QUIT","QUIT","Q","Exit after safe cleanup"),("UNDO","UNDO","CTRL+Z","Undo the last editor operation"),("REDO","REDO","CTRL+Y","Redo the last editor operation")]
  for i,(cid,label,key,desc) in enumerate(defs):self.registry.register(Command(cid,label,key,desc,lambda s,cid=cid:self.enabled(cid),lambda s,cid=cid:H[cid]()))
 def enabled(self,cid):
  if cid=="PAUSE":return self.state.playback_state==PlaybackState.PLAYING
  if cid=="EXPORT_WAV":return self.state.expression_valid
  return True
 def notify(self,m,level=NotificationLevel.INFO):getattr(self.note,level.name.lower())(m);self.state.status_message=m
 def validate(self,expr):
  try:c=self.engine.compile(expr);return True,c,""
  except (LexerError,ParseError,SemanticError,ValueError) as e:return False,None,str(e)
 def apply_editor(self):
  ok,c,err=self.validate(self.editor.text)
  if not ok:self.state.expression_valid=False;self.state.expression_error=err;self.notify("EXPRESSION INVALID",NotificationLevel.ERROR);return False
  self.state.expression,self.state.compiled_expression,self.state.expression_valid,self.state.expression_error=self.editor.text,c,True,"";self.state.project_dirty=True;self.state.preset_name="Custom";self.state.preset_builtin=False;self.notify("EXPRESSION VALID",NotificationLevel.SUCCESS);return True
 def enter_editor(self):self.state.active_screen="editor";self.editor=Editor(self.state.expression)
 def play(self):
  if not self.state.expression_valid:return self.notify("EXPRESSION INVALID",NotificationLevel.ERROR)
  if self.state.playback_state==PlaybackState.PLAYING:return
  self.playback.backend=self.backend_mgr.current
  if self.state.playback_state==PlaybackState.PAUSED and self.playback.resume():self.state.playback_state=PlaybackState.PLAYING;return
  if self.backend_mgr.current.name=="NONE":self.notify("NO AUDIO BACKEND",NotificationLevel.WARNING);return
  self.state.playback_state=PlaybackState.LOADING;self.playback.start(self.state.snapshot,self.state.compiled_expression)
 def pause(self):
  if self.state.playback_state==PlaybackState.PLAYING and self.playback.pause():self.state.playback_state=PlaybackState.PAUSED
 def stop(self):self.playback.stop();self.state.playback_state=PlaybackState.STOPPED;self.state.sample_position=0
 def reset(self):self.stop();self.notify("PLAYBACK RESET")
 def next_visualizer(self):
  vals=list(VisualizerMode);self.state.visualizer_mode=vals[(vals.index(self.state.visualizer_mode)+1)%len(vals)];self.state.project_dirty=True;self.notify("VISUALIZER: "+self.state.visualizer_mode.value)
 def zoom_in(self):
  vals=[.25,.5,1,2,4,8];self.state.visualizer_zoom=vals[min(len(vals)-1,vals.index(self.state.visualizer_zoom)+1)] if self.state.visualizer_zoom in vals else 1;self.notify(f"ZOOM: {self.state.visualizer_zoom:g}x")
 def zoom_out(self):
  vals=[.25,.5,1,2,4,8];self.state.visualizer_zoom=vals[max(0,vals.index(self.state.visualizer_zoom)-1)] if self.state.visualizer_zoom in vals else 1;self.notify(f"ZOOM: {self.state.visualizer_zoom:g}x")
 def toggle_loop(self):self.state.loop_enabled=not self.state.loop_enabled;self.state.project_dirty=True;self.notify("LOOP: "+("ON" if self.state.loop_enabled else "OFF"))
 def toggle_autopreview(self):self.state.auto_preview=not self.state.auto_preview;self.state.project_dirty=True;self.notify("AUTO PREVIEW: "+("ON" if self.state.auto_preview else "OFF"))
 def preset_cycle(self):
  ps=self.presets.list();p=ps[(next((i for i,x in enumerate(ps) if x.id==self.state.preset_id),-1)+1)%len(ps)];self.state.expression=p.expression;self.editor=Editor(p.expression);ok,c,e=self.validate(p.expression);self.state.compiled_expression=c;self.state.expression_valid=ok;self.state.expression_error=e;self.state.preset_id=p.id;self.state.preset_name=p.name;self.state.preset_builtin=p.builtin;self.state.project_dirty=True;self.notify("PRESET LOADED: "+p.name,NotificationLevel.SUCCESS)
 def settings(self):self.state.active_screen="settings";self.state.active_panel=0;self.notify("SETTINGS")
 def help(self):self.state.active_screen="help";self.state.active_panel=0;self.notify("HELP")
 def new_project(self):
  self.stop();self.state=ApplicationState(expression=DEFAULT_EXPRESSION,audio_backend_name=self.backend_mgr.current.name,sample_rate=self.cfg.default_sample_rate,volume=self.cfg.default_volume,duration=self.cfg.default_duration,fps_limit=self.cfg.fps_limit,performance_mode=PerformanceMode(self.cfg.performance_mode),unicode_mode=self.cfg.unicode_mode,animations_enabled=self.cfg.animations_enabled,autosave_enabled=self.cfg.autosave_enabled,theme=ThemeName(self.cfg.theme));self.state.recalc();self.editor=Editor(DEFAULT_EXPRESSION);self.notify("NEW PROJECT")
 def cycle_theme(self):
  vals=list(ThemeName); self.state.theme=vals[(vals.index(self.state.theme)+1)%len(vals)]; self.theme.set(self.state.theme);self.state.project_dirty=True;self.notify("THEME: "+self.state.theme.value)
 def cycle_performance(self):
  vals=list(PerformanceMode);self.state.performance_mode=vals[(vals.index(self.state.performance_mode)+1)%len(vals)];self.state.fps_limit={PerformanceMode.PERFORMANCE:60,PerformanceMode.BALANCED:30,PerformanceMode.BATTERY:15}[self.state.performance_mode];self.state.config_dirty=True;self.notify("PERFORMANCE: "+self.state.performance_mode.value)
 def toggle_unicode(self):self.state.unicode_mode=not self.state.unicode_mode;self.state.config_dirty=True;self.notify("UNICODE: "+("ON" if self.state.unicode_mode else "ASCII"))
 def toggle_animation(self):self.state.animations_enabled=not self.state.animations_enabled;self.state.config_dirty=True;self.notify("ANIMATIONS: "+("ON" if self.state.animations_enabled else "OFF"))
 def cycle_backend(self):
  order=["TERMUX_MEDIA_PLAYER","FFPLAY","MPV","APLAY","NONE"]
  current=self.backend_mgr.current.name; start=order.index(current) if current in order else 0
  for off in range(1,len(order)+1):
   name=order[(start+off)%len(order)]
   if name=="NONE" or next((b for b in self.backend_mgr.backends if b.name==name and b.is_available()),None):
    if name=="NONE":
     self.backend_mgr.current=next(b for b in self.backend_mgr.backends if b.name=="NONE")
    else:self.backend_mgr.select(name)
    self.state.audio_backend_name=self.backend_mgr.current.name;self.playback.backend=self.backend_mgr.current;self.state.config_dirty=True;self.notify("AUDIO BACKEND: "+self.state.audio_backend_name);return

 def export_wav(self):
  if not self.state.expression_valid:return self.notify("EXPORT DISABLED: INVALID EXPRESSION",NotificationLevel.ERROR)
  out=self.pm.exports/(self.state.project_name.replace("/","_")+".wav");i=1
  while out.exists():out=self.pm.exports/(f"{self.state.project_name}_{i:03d}.wav");i+=1
  try:
   self.engine.generate_wav(self.state.snapshot,self.state.compiled_expression,out);self.notify(f"EXPORT COMPLETE: {out}",NotificationLevel.SUCCESS)
  except Exception as e:self.notify("EXPORT FAILED: "+str(e),NotificationLevel.ERROR)
 def save(self):
  p=Project(project_name=self.state.project_name,expression=self.state.expression,bpm=self.state.bpm,volume=self.state.volume,duration=self.state.duration,sample_rate=self.state.sample_rate,channels=1,bit_depth=8,visualizer_mode=self.state.visualizer_mode.value,visualizer_zoom=self.state.visualizer_zoom,theme=self.state.theme.value,loop_enabled=self.state.loop_enabled,auto_preview=self.state.auto_preview)
  path=Path(self.state.project_path) if self.state.project_path else self.pm.projects/(self.state.project_name+".bbproj");self.pm.save(p,path);self.state.project_path=str(path);self.state.project_dirty=False;self.notify("PROJECT SAVED",NotificationLevel.SUCCESS)
 def quit(self):self.running=False
 def consume_events(self):
  while True:
   try:e=self.events.get_nowait()
   except queue.Empty:break
   if e.kind=="LOADING":self.state.playback_state=PlaybackState.LOADING
   elif e.kind=="PLAYING":self.state.playback_state=PlaybackState.PLAYING
   elif e.kind=="PAUSED":self.state.playback_state=PlaybackState.PAUSED
   elif e.kind=="POSITION":self.state.sample_position=e.position
   elif e.kind=="FINISHED":self.state.sample_position=0;self.state.playback_state=PlaybackState.STOPPED
   elif e.kind=="ERROR":self.state.playback_state=PlaybackState.ERROR;self.notify("AUDIO ERROR: "+e.message,NotificationLevel.ERROR)
 def handle_key(self,k):
  if self.state.active_screen=="editor":return self.handle_editor(k)
  if self.state.active_screen=="help":
   if k.key=="ESC":self.state.active_screen="dashboard"
   elif k.key=="UP":self.state.active_panel=max(0,self.state.active_panel-1)
   elif k.key=="DOWN":self.state.active_panel+=1
   return
  if self.state.active_screen=="settings":
   if k.key=="ESC":self.state.active_screen="dashboard"
   elif k.key=="T":self.cycle_theme()
   elif k.key=="F":self.cycle_performance()
   elif k.key=="U":self.toggle_unicode()
   elif k.key=="M":self.toggle_animation()
   elif k.key=="B":self.cycle_backend()
   elif k.key=="A":self.toggle_autopreview()
   elif k.key=="L":self.toggle_loop()
   elif k.ctrl and k.key.upper()=="S":self.cfgm.config.theme=self.state.theme.value;self.cfgm.config.fps_limit=self.state.fps_limit;self.cfgm.config.performance_mode=self.state.performance_mode.value;self.cfgm.config.unicode_mode=self.state.unicode_mode;self.cfgm.config.animations_enabled=self.state.animations_enabled;self.cfgm.config.autosave_enabled=self.state.autosave_enabled;self.cfgm.save();self.state.config_dirty=False;self.notify("SETTINGS SAVED",NotificationLevel.SUCCESS)
   return
  if k.ctrl and k.key.upper()=="S":self.save();return
  if k.ctrl and k.key.upper()=="Z":self.editor.undo();return
  if k.ctrl and k.key.upper()=="Y":self.editor.redo();return
  m={"N":"NEW","ENTER":"PLAY"," ":"PAUSE","SPACE":"PAUSE","S":"STOP","R":"RESET","E":"EDIT","P":"PRESETS","V":"VISUALIZER_NEXT","+":"ZOOM_IN","-":"ZOOM_OUT","W":"EXPORT_WAV","O":"SETTINGS","?":"HELP","L":"TOGGLE_LOOP","A":"TOGGLE_AUTO_PREVIEW","Q":"QUIT"};cid=m.get(k.key)
  if cid=="NEW": self.new_project(); return
  if cid and self.enabled(cid):self.registry.get(cid).handler(self)
 def handle_editor(self,k):
  if k.key=="ESC":self.state.active_screen="dashboard";return
  if k.ctrl and k.key.upper()=="ENTER":self.apply_editor();self.state.active_screen="dashboard";return
  if k.key in ("ENTER",):self.apply_editor();self.state.active_screen="dashboard";return
  if k.key=="LEFT":self.editor.left()
  elif k.key=="RIGHT":self.editor.right()
  elif k.key=="HOME":self.editor.home()
  elif k.key=="END":self.editor.end()
  elif k.key=="DELETE":self.editor.delete()
  elif k.key=="CTRL_C":self.state.active_screen="dashboard"
  elif k.key in ("",):self.editor.backspace()
  elif k.text and k.text.isprintable() and not k.ctrl:self.editor.insert(k.text)
  elif k.key=="CTRL_Z":self.editor.undo()
  elif k.key=="CTRL_Y":self.editor.redo()
 def render_screen(self):
  size=self.term.size();lay=self.layout.calculate(size.width,size.height); vis=self.visual.render(self.state.visualizer_mode.value,max(1,lay.visualizer.width-2),max(1,lay.visualizer.height-3),self.state.visualizer_zoom,self.state.playback_state==PlaybackState.PAUSED,self.state.unicode_mode); note=[n.message for n in self.note.active()]; self.renderer.render(self.state,lay,vis,self.editor.text,note)
 def run(self):
  self.setup();
  if not self.term.stdin.isatty():raise RuntimeError("INTERACTIVE TERMINAL REQUIRED")
  self.running=True;old_handler=signal.getsignal(signal.SIGINT);signal.signal(signal.SIGINT,lambda *_:self.stop() if self.state.playback_state in (PlaybackState.PLAYING,PlaybackState.PAUSED) else setattr(self,'running',False))
  try:
   self.term.alt_screen(True);self.term.enter_raw();self.term.clear();self.term.write("\n".join(self._splash_lines()));self.term.flush();time_module.sleep(.35)
   while self.running:
    self.consume_events();
    for k in self.term.poll(0.01):self.handle_key(k)
    if self.state.playback_state==PlaybackState.PLAYING:self.visual.update(self.engine.generate_chunk(self.state.compiled_expression,self.state.sample_position, min(1024,self.state.sample_rate//10),self.state.volume))
    self.render_screen();time_module.sleep(1/max(5,self.state.fps_limit))
  finally:
   try:self.playback.stop();self.cfgm.save()
   finally:self.term.restore();signal.signal(signal.SIGINT,old_handler)
 def _splash_lines(self):
  s=self.term.size();lines=SPLASH_SKULL.splitlines();return (["" ,*lines,"",APP_NAME,"TERMINAL AUDIO WORKSTATION",f"VERSION {APP_VERSION}",f"BACKEND {self.backend_mgr.current.name}",f"TERMINAL {s.width}x{s.height}","INITIALIZING...",""])

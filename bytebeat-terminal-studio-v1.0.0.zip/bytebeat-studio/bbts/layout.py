from dataclasses import dataclass
from enum import Enum
from .terminal import TerminalSize
class LayoutMode(Enum): ULTRA_COMPACT="ultra";COMPACT="compact";MEDIUM="medium";LARGE="large";WIDE="wide"
@dataclass(frozen=True)
class Rect:x:int;y:int;width:int;height:int
@dataclass(frozen=True)
class Layout: mode:LayoutMode;header:Rect;visualizer:Rect;editor:Rect;parameters:Rect;engine:Rect;footer:Rect;status:Rect
class LayoutManager:
 def calculate(self,w,h):
  if w<52:mode=LayoutMode.ULTRA_COMPACT
  elif w<70:mode=LayoutMode.COMPACT
  elif w<100:mode=LayoutMode.MEDIUM
  elif w<140:mode=LayoutMode.LARGE
  else:mode=LayoutMode.WIDE
  header=Rect(1,1,w,3);status=Rect(1,h,w,1);footer=Rect(1,h-1,w,1);body_y=4;body_h=max(4,h-6);vis_h=max(4,body_h//2);visual=Rect(1,body_y,w,vis_h);editor=Rect(1,body_y+vis_h,w,4)
  lower_y=editor.y+editor.height;lower_h=max(1,h-lower_y-2); half=max(1,w//2)
  if mode in (LayoutMode.MEDIUM,LayoutMode.LARGE,LayoutMode.WIDE):params=Rect(1,lower_y,half,lower_h);engine=Rect(half+1,lower_y,w-half,lower_h)
  else:params=Rect(1,lower_y,w,lower_h);engine=Rect(1,lower_y,w,lower_h)
  return Layout(mode,header,visual,editor,params,engine,footer,status)

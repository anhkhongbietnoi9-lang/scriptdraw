from dataclasses import dataclass, field
from enum import Enum
from time import time

class PlaybackState(Enum): STOPPED="STOPPED"; PLAYING="PLAYING"; PAUSED="PAUSED"; LOADING="LOADING"; ERROR="ERROR"
class VisualizerMode(Enum): WAVE="WAVE"; BAR="BAR"; SPECTRUM="SPECTRUM"; OSCILLOSCOPE="OSCILLOSCOPE"; MATRIX="MATRIX"
class ThemeName(Enum): CYBER_CYAN="CYBER_CYAN"; PURPLE_NIGHT="PURPLE_NIGHT"; MATRIX="MATRIX"; AMBER_CRT="AMBER_CRT"; MONOCHROME="MONOCHROME"
class PerformanceMode(Enum): PERFORMANCE="PERFORMANCE"; BALANCED="BALANCED"; BATTERY="BATTERY"
class NotificationLevel(Enum): INFO="INFO"; SUCCESS="SUCCESS"; WARNING="WARNING"; ERROR="ERROR"
class BackendState(Enum): AVAILABLE="AVAILABLE"; UNAVAILABLE="UNAVAILABLE"; BROKEN="BROKEN"

@dataclass(frozen=True)
class RenderSettings:
    expression:str; sample_rate:int; duration:int; volume:int; channels:int=1; bit_depth:int=8; loop:bool=False
    @property
    def total_samples(self)->int: return self.sample_rate*self.duration

@dataclass
class ApplicationState:
    project_name:str="Untitled"; project_path:str=""; project_dirty:bool=False
    expression:str=""; compiled_expression:object|None=None; expression_valid:bool=False; expression_error:str=""
    bpm:int=120; volume:int=80; duration:int=10; sample_rate:int=8000; channels:int=1; bit_depth:int=8
    playback_state:PlaybackState=PlaybackState.STOPPED; sample_position:int=0; total_samples:int=80000
    visualizer_mode:VisualizerMode=VisualizerMode.WAVE; visualizer_zoom:float=1.0; theme:ThemeName=ThemeName.CYBER_CYAN
    fps_limit:int=30; performance_mode:PerformanceMode=PerformanceMode.BALANCED; unicode_mode:bool=True; animations_enabled:bool=True
    loop_enabled:bool=False; auto_preview:bool=False; autosave_enabled:bool=True
    audio_backend_name:str="NONE"; active_screen:str="dashboard"; active_panel:int=0; active_modal:str=""; status_message:str="READY"
    config_dirty:bool=False; preset_name:str="Classic"; preset_id:str="classic"; preset_builtin:bool=True
    @property
    def snapshot(self)->RenderSettings: return RenderSettings(self.expression,self.sample_rate,self.duration,self.volume,self.channels,self.bit_depth,self.loop_enabled)
    def recalc(self): self.total_samples=self.sample_rate*self.duration

@dataclass(frozen=True)
class KeyEvent:
    key:str; text:str=""; ctrl:bool=False; alt:bool=False; shift:bool=False

@dataclass
class Notification:
    level:NotificationLevel; message:str; duration:float=2.5; created_at:float=field(default_factory=time)
    @property
    def expired(self): return time()-self.created_at >= self.duration

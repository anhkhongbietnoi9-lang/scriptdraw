from dataclasses import dataclass
from .state import ThemeName
@dataclass(frozen=True)
class Theme:
    primary:int; secondary:int; accent:int; success:int; warning:int; error:int; text:int; dim:int; border:int; active_border:int; background:int
THEMES={
 ThemeName.CYBER_CYAN:Theme(36,37,96,32,33,31,37,90,36,96,40),
 ThemeName.PURPLE_NIGHT:Theme(35,37,95,32,33,31,37,90,35,95,40),
 ThemeName.MATRIX:Theme(32,37,92,32,33,31,37,90,32,92,40),
 ThemeName.AMBER_CRT:Theme(33,37,93,32,33,31,37,90,33,93,40),
 ThemeName.MONOCHROME:Theme(37,37,97,37,37,37,37,90,37,97,40),
}
class ThemeManager:
 def __init__(self,name=ThemeName.CYBER_CYAN): self.name=name
 @property
 def theme(self): return THEMES[self.name]
 def set(self,name): self.name=ThemeName(name)

import tempfile,unittest,wave
from pathlib import Path
from bbts.audio.wav import write_wav_stream,verify_wav
class TestWav(unittest.TestCase):
 def test_header(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/"x.wav";write_wav_stream(p,8000,[bytes([0])*8000]);self.assertTrue(verify_wav(p,8000,8000))

import unittest
from bbts.layout import LayoutManager
class TestLayout(unittest.TestCase):
 def test_sizes(self):
  m=LayoutManager()
  for w,h in [(52,18),(60,20),(80,24),(100,30),(120,40),(160,50)]:
   l=m.calculate(w,h)
   for r in [l.header,l.visualizer,l.editor,l.parameters,l.engine,l.footer,l.status]:self.assertLessEqual(r.x+r.width-1,w);self.assertLessEqual(r.y+r.height-1,h)

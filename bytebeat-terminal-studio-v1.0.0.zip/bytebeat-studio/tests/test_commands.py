import ast,unittest
from pathlib import Path
from bbts.commands import CommandRegistry,Command
from bbts.constants import SPLASH_SKULL
class TestCommands(unittest.TestCase):
 def test_registry(self):
  r=CommandRegistry();r.register(Command("X","X","X","does x",lambda s:True,lambda:None));self.assertEqual(r.get("X").shortcut,"X")
 def test_no_curses_no_eval_and_skull(self):
  src="\n".join(p.read_text(encoding="utf-8") for p in Path("bbts").rglob("*.py"));self.assertNotIn("import curses",src);self.assertNotIn("eval(",src);self.assertEqual(SPLASH_SKULL.splitlines()[0],"          .__,^._");self.assertIn("---...",SPLASH_SKULL)

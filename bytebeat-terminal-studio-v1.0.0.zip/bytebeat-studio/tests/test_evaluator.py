import unittest
from bbts.parser.compiler import BytebeatCompiler
from bbts.audio.engine import BytebeatEngine
class TestEval(unittest.TestCase):
 def test_bytes(self):
  e=BytebeatEngine(BytebeatCompiler())
  for expr,expected in [("0",0),("255",255),("t",7),("t&255",7)]:self.assertEqual(e.render_sample(e.compile(expr),7,100),expected)
 def test_security(self):
  c=BytebeatCompiler()
  for e in ['__import__("os")','open("file")','os.system("x")','eval("1")','globals()']:
   with self.assertRaises(Exception):c.compile(e)

import tempfile,unittest
from pathlib import Path
from bbts.project.presets import PresetManager,BUILTINS
from bbts.parser.compiler import BytebeatCompiler
class TestPresets(unittest.TestCase):
 def test_builtins_compile(self):
  c=BytebeatCompiler()
  for p in BUILTINS:c.compile(p.expression)
 def test_custom(self):
  with tempfile.TemporaryDirectory() as d:
   m=PresetManager(Path(d)/"custom.json",BytebeatCompiler());p=m.create("X","Test","d","t&255");self.assertFalse(p.builtin);self.assertIsNotNone(m.get(p.id));m.delete(p.id);self.assertIsNone(m.get(p.id))

import tempfile,unittest
from pathlib import Path
from bbts.project.manager import ProjectManager
from bbts.project.model import Project
class TestProject(unittest.TestCase):
 def test_roundtrip(self):
  with tempfile.TemporaryDirectory() as d:
   m=ProjectManager(Path(d));p=Project(project_name="A",expression="t",sample_rate=16000,duration=2,theme="MATRIX",visualizer_mode="SPECTRUM");q=Path(d)/"a.bbproj";m.save(p,q);r=m.load(q);self.assertEqual(r.expression,"t");self.assertEqual(r.sample_rate,16000);self.assertEqual(r.theme,"MATRIX")

import unittest
from bbts.parser import BytebeatTokenizer
class TestTokenizer(unittest.TestCase):
 def test_ops(self):self.assertEqual([t.value for t in BytebeatTokenizer().tokenize("(t*5)&(t>>7)") if t.kind!="EOF"],["(","t","*","5",")","&","(","t",">>","7",")"])

import unittest
from bbts.terminal import visible_width,truncate_to_width,pad_to_width
class TestTerminalText(unittest.TestCase):
 def test_width(self):self.assertEqual(visible_width("[31mAB[0m"),2);self.assertEqual(visible_width("界"),2)
 def test_truncate(self):self.assertEqual(truncate_to_width("abc",2),"ab");self.assertEqual(visible_width(pad_to_width("x",5)),5)

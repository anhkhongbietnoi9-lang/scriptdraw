import unittest
from bbts.parser import BytebeatParser,ParseError
from bbts.parser.compiler import BytebeatCompiler
class TestParser(unittest.TestCase):
 def test_valid(self):
  c=BytebeatCompiler()
  for e in ["0","255","t","t+1","t*5","t>>4","(t*5)&255","(t>>4)|(t<<3)","(t*5&t>>7)|(t*3&t>>10)"]:
   c.compile(e)
 def test_invalid(self):
  c=BytebeatCompiler()
  for e in ["( t*","t>> @","unknown_identifier"]:
   with self.assertRaises(Exception):c.compile(e)

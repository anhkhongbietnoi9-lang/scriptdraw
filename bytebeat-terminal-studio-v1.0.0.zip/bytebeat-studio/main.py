#!/usr/bin/env python3
import datetime
import sys
import traceback
from pathlib import Path

from bbts.app import Application


def main() -> int:
    if sys.version_info < (3, 12):
        print("PYTHON VERSION UNSUPPORTED: Python 3.12+ required.", file=sys.stderr)
        return 2
    app = Application()
    try:
        app.run()
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        logdir = Path.home() / ".bbts" / "logs"
        logdir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        report = logdir / f"crash-{stamp}.log"
        report.write_text(traceback.format_exc(), encoding="utf-8")
        try:
            app.term.restore()
        except Exception:
            pass
        print(f"FATAL ERROR: {exc}\nCrash report: {report}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pathlib import Path
from bbts.parser.compiler import BytebeatCompiler
from bbts.audio.engine import BytebeatEngine,EngineSnapshot
from bbts.audio.wav import verify_wav
import tempfile
c=BytebeatCompiler();e=BytebeatEngine(c);compiled=e.compile("(t*5&t>>7)|(t*3&t>>10)")
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/"smoke.wav";s=EngineSnapshot(compiled.source,8000,1,80);e.generate_wav(s,compiled,p);assert verify_wav(p,8000,8000)
print("BBTS smoke test: OK")
